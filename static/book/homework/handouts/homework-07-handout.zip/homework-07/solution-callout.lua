-- Set `withhold-solutions: true` in a homework's front matter while the
-- assignment is still out. Solution blocks are then dropped from this page
-- rather than rendered collapsed, so the served page carries no answers.
-- Set it to `false` once the assignment has come due: bin/generate-index.py
-- releases a single-file homework's solutions page only then.
--
-- A starter is the code the student's answer box opens with in the handout,
-- put there by bin/make-handout.py. This page shows it as the Template, so the
-- author reads exercise, Template and solution together. The handout and the
-- solutions edition carry no starters. Set `omit-starter: true` to drop them.
local withhold_solutions = false
local omit_starter = false

function Meta(meta)
  withhold_solutions = meta['withhold-solutions'] == true
  omit_starter = meta['omit-starter'] == true
end

local function titled_callout(div, type, title, collapse)
  if div.content[1] ~= nil and div.content[1].t == "Header" then
    title = div.content[1]
    div.content:remove(1)
  end
  return quarto.Callout({
    type = type,
    content = div,
    title = title,
    collapse = collapse,
  })
end

function Div(div)
  if div.classes:includes("callout-starter") then
    if omit_starter then
      return {}
    end
    return quarto.Callout({
      type = "note",
      content = div.content,
      title = "Template",
    })
  end
  if div.classes:includes("callout-exercise") then
    return titled_callout(div, "exercise", "")
  end
  if div.classes:includes("callout-solution") then
    if withhold_solutions then
      return {}
    end
    return titled_callout(div, "solution", "Solution", true)
  end
end

-- A `#sol-` id makes Quarto parse the solution into a proof node of type
-- Solution before this filter runs. Div above has already emptied the div it
-- carries, which leaves a proof Quarto cannot render, so the whole node goes.
function Proof(proof)
  if withhold_solutions and proof.type == "Solution" then
    return {}
  end
end

-- Two passes, deliberately. Pandoc walks blocks before Meta, so a single-pass
-- filter would consult withhold_solutions while it was still false and render
-- the solutions anyway. Reading Meta in its own earlier pass is what makes the
-- flag take effect.
return {
  { Meta = Meta },
  { Div = Div, Proof = Proof },
}
