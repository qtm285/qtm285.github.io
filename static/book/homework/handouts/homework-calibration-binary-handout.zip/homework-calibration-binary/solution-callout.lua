function Div(div)
  -- A starter is the code the student's answer box opens with in the handout, put
  -- there by bin/make-handout.py. On this page the solution is shown instead, so
  -- the starter would just be the same code twice.
  if div.classes:includes("callout-starter") then
    return {}
  end
  if div.classes:includes("callout-exercise") then
    local title = ""
    if div.content[1] ~= nil and div.content[1].t == "Header" then
      title = div.content[1]
      div.content:remove(1)
    end
    return quarto.Callout({
      type = "exercise",
      content = div,
      title = title,
    })
  end
  if div.classes:includes("callout-solution") then
    local title = "Solution"
    if div.content[1] ~= nil and div.content[1].t == "Header" then
      title = div.content[1]
      div.content:remove(1)
    end
    return quarto.Callout({
      type = "solution",
      content = div,
      title = title,
      collapse = true
    })
  end
end
