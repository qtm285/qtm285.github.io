Homework 6 is done by hand. Save your work as a PDF in this folder, then submit the whole homework folder through Positron as usual.
