-- Warn during Quarto render when an answer was typed below its answer block.
-- Compare parsed blocks so Visual Editor wrapping and footnotes stay equivalent.

local function read_file(filename)
  local file = io.open(filename, "r")
  if not file then return nil end
  local contents = file:read("*a")
  file:close()
  return contents
end

local function trim(text)
  return text:match("^%s*(.-)%s*$")
end

local function is_placeholder(block)
  local value = trim(pandoc.utils.stringify(block)):lower()
  value = value:gsub("^%(", ""):gsub("%)$", "")
  return trim(value) == "your answer here"
end

local function signature(block)
  local document = pandoc.Pandoc({block}):walk({
    SoftBreak = function() return pandoc.Space() end,
  })
  return pandoc.write(document, "json")
end

local function unanswered(div)
  for _, block in ipairs(div.content) do
    if trim(pandoc.utils.stringify(block)) ~= "" and not is_placeholder(block) then
      return false
    end
  end
  return true
end

local function dirname(filename)
  return filename:match("^(.*[/\\])") or ""
end

function Meta(meta)
  local baseline_value = meta["tlda-answer-baseline"]
  local input = quarto and quarto.doc and quarto.doc.input_file
  if not baseline_value or not input then return nil end

  local baseline_name = pandoc.utils.stringify(baseline_value)
  local source = read_file(input)
  local baseline = read_file(dirname(input) .. baseline_name)
  if not source or not baseline then
    io.stderr:write("WARNING: answer-placement check could not read its pristine handout baseline.\n")
    return nil
  end

  local template_blocks = {}
  pandoc.read(baseline, "markdown"):walk({
    Block = function(block) template_blocks[signature(block)] = true end,
  })

  pandoc.read(source, "markdown"):walk({
    Blocks = function(blocks)
      local answer_id = nil
      for _, block in ipairs(blocks) do
        if block.t == "Div" then
          answer_id = nil
          if block.identifier:match("^ans[%w_-]+$") and unanswered(block) then
            answer_id = block.identifier
          end
        elseif block.t == "Header" then
          answer_id = nil
        elseif answer_id and not template_blocks[signature(block)] then
          local excerpt = pandoc.utils.stringify(block):gsub("%s+", " "):sub(1, 60)
          io.stderr:write(string.format(
            'WARNING: "%s" is outside answer block #%s and will not be marked. Move it inside that answer block.\n',
            excerpt, answer_id
          ))
          answer_id = nil
        end
      end
    end,
  })
  return nil
end
