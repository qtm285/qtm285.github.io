class.theme = theme(plot.background = element_rect(fill = "transparent", colour = NA),
        panel.background = element_rect(fill = "transparent", colour = NA),
                    legend.background = element_rect(fill="transparent", colour = NA),
                    legend.box.background = element_rect(fill="transparent", colour = NA),
                    legend.key = element_rect(fill="transparent", colour = NA),
        axis.ticks.x = element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.x  = element_text(colour = "#aaaaaa"),
        axis.text.y  = element_text(colour = "#aaaaaa"),
        axis.title.x  = element_text(colour = "#aaaaaa"),
        axis.title.y  = element_text(colour = "#aaaaaa", angle=90)
)

theme_set(class.theme)
theme_update(axis.title.x  = element_blank(),
             axis.title.y  = element_blank())
simplified.theme = theme_get()

theme_update(axis.text.x   = element_blank(), 
              axis.text.y   = element_blank())
blank.theme = theme_get()

theme_update(panel.grid.major=element_line(color=rgb(1,0,0,.1,  maxColorValue=1)),
           panel.grid.minor=element_line(color=rgb(0,1,0,.1, maxColorValue=1)))
grid.theme = theme_get()

whitebg.theme = function(lightgray="#cccccc", gridcolor=rgb(0,0,0,.07, maxColorValue=1), labs=FALSE) {
    theme(
        plot.background = element_rect(fill = "transparent", colour = NA),
        panel.background = element_rect(fill = "transparent", colour = NA),
                    legend.background = element_rect(fill="transparent", colour = NA),
                    legend.box.background = element_rect(fill="transparent", colour = NA),
                    legend.key = element_rect(fill="transparent", colour = NA),
        axis.ticks.x = element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.x  = element_text(colour = lightgray),
        axis.text.y  = element_text(colour = lightgray),
        axis.title.x  = if(labs) { element_text(colour=lightgray) } else { element_blank() },
        axis.title.y  = if(labs) { element_text(colour=lightgray, angle=90) } else { element_blank() },
        panel.grid.major=element_line(colour=gridcolor),
        panel.grid.minor=element_line(colour=gridcolor, linewidth=0.25))
}
labs = function(...) { list(ggplot2::labs(...), whitebg.theme(labs=TRUE)) }
whitebw.theme = whitebg.theme

# Plots without labs() inherit the global theme: leave it on class.theme, not the debug grid above.
theme_set(simplified.theme)

# Bars carry a thin outline so their shape survives dots and annotation lines.
# geom_histogram and geom_col both draw through GeomBar, so this covers all three.
# A call that passes colour or linewidth overrides it.
update_geom_defaults("bar", list(colour = "gray", linewidth = 0.02))


# These are the HTML entities for shapes we use in the text. 
# This lets us write `r circle` instead of &#9679; when we want a circle.
triangle =  '&#9650;'
circle = '&#9679;'
pointrange = '&#9087;'

filled = list(
    downtriangle = 25, 
    uptriangle = 24,
    diamond = 23,
    square = 22,
    circle = 21)
comparison_styles = list(
    scale_shape_manual(values=c('0'=filled$downtriangle, '1'=filled$uptriangle)),
    guides(shape='none', color='none', fill='none'))

twocolor.red   = rgb(248,118,109, maxColorValue=255)
twocolor.green = rgb(0,191,196,   maxColorValue=255)
groupa = twocolor.red
groupb = twocolor.green

pink     = '#ef476f'  # rgb(239,71,111)
mustard  = '#ffd166'  # rgb(255,209,102)
green    = '#06d6a0'  # rgb(6, 214,160)
teal     = '#118ab2'  # rgb(17,138,178)
midnight = '#073b4c'  # rgb(7,59,76)
# fwiw, col2rgb is a function that converts a color to its RGB values

map.background = green
polla  = midnight
pollb  = pink
pollc  = teal
polld  = green
polle  = mustard
# THESE COLORS ARE DEFINED IN class.scss, TOO. IF YOU CHANGE THEM HERE, CHANGE THEM THERE.

ellipsis = function(df, nhead=5L, ntail=2) {
    rownames(df) = if(is.null(rownames(df))) { 
        as.character(1:nrow(df)) 
    } else { 
        as.character(rownames(df))
    }
    stopifnot("data.frame" %in% class(df))
    els = rep(NA, ncol(df)) |>
        matrix(nrow=1, dimnames=list(NULL, names(df))) |>
        data.frame(stringsAsFactors=FALSE) |>
        as_tibble()
    rownames(els) = "⋮"
    dplyr::bind_rows(head(df, nhead), els, tail(df, ntail))
}
options(knitr.kable.NA = '')
