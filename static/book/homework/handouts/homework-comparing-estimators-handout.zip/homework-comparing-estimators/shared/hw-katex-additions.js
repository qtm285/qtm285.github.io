// The homework macro additions for the student zips' KaTeX render.
//
// One source file: edit here. `bin/build-handouts.py` stages this file, plus
// katex-assets/macros.js and shared/katex-course-shim.html, into every handout
// zip; the zip's yaml names all three in include-in-header, and the shim feeds
// the merged set to katex.render (pandoc's own render loop cannot take macros
// by configuration -- see the shim's header).
//
// What belongs here: only what katex-assets/macros.js does NOT already carry.
// Both KaTeX homework QMDs author their prior macros in hidden blocks, so those
// definitions stay with each document and are not preloaded here.
window.__tldaKatexMacros = window.__tldaKatexMacros || {};
Object.assign(window.__tldaKatexMacros, {});
